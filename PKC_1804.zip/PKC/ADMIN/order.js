function navigate(page) {
    window.location.href = page;
}

//lịch sử đơn hàng
async function fetchOrders() {
    try {
        const response = await fetch('https://681eaa08c1c291fa6634b56c.mockapi.io/courses');
        if (!response.ok) {
            throw new Error(`Lỗi: ${response.status} - ${response.statusText}`);
        }

        const orders = await response.json();
        displayOrders(orders);
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu đơn hàng:', error);
        alert('Không thể tải dữ liệu đơn hàng!');
    }
}


function displayOrders(orders) {
    const orderList = document.getElementById('order-list');
    orderList.innerHTML = '';

    orders.forEach((order) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${order.id}</td>
            <td>${order.title}</td>
            <td>${order.instructor}</td>
            <td><img class="img text-center" src="${order.image}" alt="Hình ảnh sản phẩm" style="width: 50%; height: 100px;"></td>
            <td>${order.description}</td>
            <td>${order.price.toLocaleString()} đ</td>
            <td>${order.name}</td>
            <td>${order.TrangThai ? 'Hoàn thành' : 'Đang xử lý'}</td>
        `;
        orderList.appendChild(row);
    });
}

window.onload = fetchOrders;
