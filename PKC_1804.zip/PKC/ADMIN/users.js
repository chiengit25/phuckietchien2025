function navigate(page) {
    window.location.href = page;
  }

// danh sách khách hàng
  let currentEditId = null;

  async function loadCustomers() {
    try {
      console.log("Đang tải dữ liệu từ API...");
      const response = await fetch('https://681eaa08c1c291fa6634b56c.mockapi.io/users');

      if (!response.ok) {
        throw new Error(`Lỗi: ${response.status} - ${response.statusText}`);
      }

      const data = await response.json();
      console.log("Dữ liệu nhận được:", data);

      const customerList = document.getElementById('customer-list');

      if (data.length > 0) {
        customerList.innerHTML = '';
        data.forEach((customer, index) => {
          const row = document.createElement('tr');

          row.innerHTML = `
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.createdAt}</td>
            <td>${customer.Status ? 'Hoạt động' : 'Ngừng hoạt động'}</td>
            <td>
              <button onclick="editCustomer(${customer.id})">Sửa</button>
              <button onclick="deleteCustomer(${customer.id})">Xóa</button>
            </td>
          `;

          customerList.appendChild(row);
        });
      } else {
        customerList.innerHTML = '<tr><td colspan="7">Không có dữ liệu khách hàng</td></tr>';
      }
    } catch (error) {
      console.error('Lỗi khi tải dữ liệu:', error);
      alert('Không thể tải dữ liệu khách hàng!');
    }
  }

  function navigate(page) {
    window.location.href = page;
  }

  function editCustomer(id) {
  fetch(`https://681eaa08c1c291fa6634b56c.mockapi.io/users/${id}`)
    .then(response => response.json())
    .then(customer => {
      const oldForm = document.getElementById('editFormRow');
      if (oldForm) oldForm.remove();

      const row = document.createElement('tr');
      row.id = 'editFormRow';
      row.innerHTML = `
        <td colspan="7">
          <div class="card p-3">
            <h5 class="mb-3">Chỉnh sửa Khách Hàng</h5>
            <div class="row g-2">
              <div class="col-md-2">
                <input id="editName" class="form-control" placeholder="Họ Tên" value="${customer.name}">
              </div>
              <div class="col-md-2">
                <input id="editEmail" class="form-control" placeholder="Email" value="${customer.email}">
              </div>
              <div class="col-md-2">
              <input id="editcreatedAt" class="form-control" placeholder="createdAt" value="${customer.createdAt}">
              </div>
              <div class="col-md-2">
                <select id="editStatus" class="form-select">
                  <option value="true" ${customer.status ? 'selected' : ''}>Hoạt động</option>
                  <option value="false" ${!customer.status ? 'selected' : ''}>Ngừng hoạt động</option>
                </select>
              </div>
              <div class="col-md-2 d-flex gap-2">
                <button class="btn btn-success w-100" onclick="saveCustomer()">Lưu</button>
                <button class="btn btn-secondary w-100" onclick="closeEditForm()">Hủy</button>
              </div>
            </div>
          </div>
        </td>
      `;

      const currentRow = document.querySelector(`button[onclick="editCustomer(${id})"]`).closest('tr');
      currentRow.insertAdjacentElement('afterend', row);
      currentEditId = id;
    });
}
    async function saveCustomer() {
    const updatedCustomer = {
        name: document.getElementById('editName').value,
        email: document.getElementById('editEmail').value,
        createdAt: document.getElementById('editcreatedAt').value,
        Status: document.getElementById('editStatus').value === 'true'
    };

    await fetch(`https://681eaa08c1c291fa6634b56c.mockapi.io/users/${currentEditId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedCustomer)
    });

    alert('Cập nhật thành công!');
    closeEditForm();
    loadCustomers();
    }



    async function deleteCustomer(id) {
    if (confirm('Bạn có chắc chắn muốn xóa khách hàng này không?')) {
      await fetch(`https://681eaa08c1c291fa6634b56c.mockapi.io/users/${id}`, {
        method: 'DELETE'
      });

      alert('Xóa thành công!');
      loadCustomers();
    }
  }

    function closeEditForm() {
    const formRow = document.getElementById('editFormRow');
    if (formRow) {
        formRow.remove();
    }
    }

  window.onload = loadCustomers;
async function loadCustomers() {
try {
  const response = await fetch('https://681eaa08c1c291fa6634b56c.mockapi.io/users');
  const data = await response.json();

  const customerList = document.getElementById('customer-list');
  let totalCustomers = 0;
  let totalBalance = 0;

  if (data.length > 0) {
    customerList.innerHTML = '';
    data.forEach((customer, index) => {
      totalCustomers++;
      totalBalance += customer.balance;

      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${customer.id}</td>
        <td>${customer.name}</td>
        <td>${customer.email}</td>
        <td>${customer.createdAt}</td>
        <td>${customer.Status ? 'Hoạt động' : 'Ngừng hoạt động'}</td>
        <td>
        <button class="btn btn-success btn-sm me-1" onclick="editCustomer(${customer.id})">Sửa</button>
        <button class="btn btn-danger btn-sm" onclick="deleteCustomer(${customer.id})">Xóa</button>
        </td>
      `;
      customerList.appendChild(row);
    });
  } else {
    customerList.innerHTML = '<tr><td colspan="7">Không có dữ liệu khách hàng</td></tr>';
  }

  //cập nhật tổng số khách hàng
  document.getElementById('total-customers').innerHTML = `<strong>${totalCustomers}</strong> khách hàng`;

} catch (error) {
  console.error('Lỗi khi tải dữ liệu:', error);
  alert('Không thể tải dữ liệu khách hàng!');
}
}