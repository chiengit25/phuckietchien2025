const apiUrl = "https://681eaa08c1c291fa6634b56c.mockapi.io/courses";

document.addEventListener("DOMContentLoaded", fetchProducts);

async function fetchProducts() {
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            console.log("Lỗi khi tải sản phẩm.");
            return;
        }
        const products = await response.json();
        displayProducts(products);
    } catch (error) {
        console.error("Lỗi mạng:", error);
    }
}

function displayProducts(products) {
    let productList = document.getElementById("product-list");
    let content = "";
    products.forEach((product, index) => {
        content += `
            <tr>
                <td>${index + 1}</td> 
                <td>${product.title}</td>
                <td>${product.instructor}</td>
                <td><img class="img text-center" src="${product.image}" alt="Hình ảnh sản phẩm" style="width: 50%; height: 100px;"></td>
                <td>${product.description}</td>
                <td>${Number(product.price).toLocaleString()} đ</td>
                <td>
                    <button class="btn btn-success btn-sm me-1"
                        onclick="showEditForm('${product.id}', '${encodeURIComponent(product.title)}', '${encodeURIComponent(product.instructor)}', '${encodeURIComponent(product.image)}', '${encodeURIComponent(product.description)}', ${product.price})">Sửa
                    </button>
                    <button class="btn btn-danger btn-sm"
                        onclick="deleteProduct('${product.id}')">Xóa
                    </button>
                </td>
            </tr>
        `;
    });
    productList.innerHTML = content;
}

async function deleteProduct(id) {
    if (!id) {
        alert("Không tìm thấy sản phẩm để xóa!");
        return;
    }

    if (confirm("Bạn có chắc muốn xóa sản phẩm này?")) {
        try {
            const response = await fetch(`${apiUrl}/${id}`, { method: "DELETE" });
            if (!response.ok) {
                throw new Error("Lỗi khi xóa sản phẩm");
            }
            alert("Sản phẩm đã được xóa!");
            fetchProducts();
        } catch (error) {
            console.error("Lỗi:", error);
            alert("Không thể xóa sản phẩm. Vui lòng thử lại.");
        }
    }
}

function showEditForm(id, title, instructor, image, description, price) {
    document.getElementById("editProductId").value = id;
    document.getElementById("editProductName").value = decodeURIComponent(title);
    document.getElementById("editProductInstructor").value = decodeURIComponent(instructor);
    document.getElementById("editProductImage").value = decodeURIComponent(image);
    document.getElementById("editProductDescription").value = decodeURIComponent(description);
    document.getElementById("editProductPrice").value = price;

    const modal = new bootstrap.Modal(document.getElementById("editModal"));
    modal.show();
}

async function saveEditProduct() {
    const id = document.getElementById("editProductId").value;
    const title = document.getElementById("editProductName").value;
    const instructor = document.getElementById("editProductInstructor").value;
    const image = document.getElementById("editProductImage").value;
    const description = document.getElementById("editProductDescription").value;
    const price = document.getElementById("editProductPrice").value;

    if (!id || !title || !instructor || !image || !description || !price) {
        alert("Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    const updatedProduct = {
        title: title,
        instructor: instructor,
        image: image,
        description: description,
        price: parseFloat(price),
    };

    try {
        const response = await fetch(`${apiUrl}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedProduct)
        });

        if (!response.ok) throw new Error("Lỗi khi cập nhật sản phẩm");

        alert("Cập nhật sản phẩm thành công!");
        fetchProducts();
        bootstrap.Modal.getInstance(document.getElementById("editModal")).hide();
    } catch (error) {
        console.error("Lỗi:", error);
        alert("Có lỗi xảy ra khi cập nhật sản phẩm.");
    }
}

async function addProduct() {
    const title = document.getElementById("productCode").value;
    const instructor = document.getElementById("productInstructor").value;
    const image = document.getElementById("productImage").value;
    const description = document.getElementById("editProductDescription").value;
    const price = document.getElementById("productPrice").value;

    if (!title || !instructor || !image || !description || !price) {
        alert("Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    const newProduct = {
        title: title,
        instructor: instructor,
        image: image,
        description: description,
        price: parseFloat(price),
    };

    try {
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newProduct)
        });

        if (!response.ok) throw new Error("Lỗi khi thêm sản phẩm");

        alert("Thêm sản phẩm thành công!");
        fetchProducts();
        document.querySelector('form').reset(); 
    } catch (error) {
        console.error("Lỗi:", error);
        alert("Có lỗi xảy ra khi thêm sản phẩm.");
    }
}
