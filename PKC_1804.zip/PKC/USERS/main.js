const API = "https://681eaa08c1c291fa6634b56c.mockapi.io/courses";

let display = () => {
    let parent = document.getElementById("showProduct")
    parent.innerHTML = "";
    let content = "";

    fetch(API)
    .then(res => res.json())
    .then(data => {
        data.forEach(element => {
            content += `
            <div class="card-wrap col-3 p-2">
                    <div class="card" style="width: 18rem;">
                    <img src="${element.image}" class="card-img-top" alt="...">
                    <div class="card-body">
                    <h2 class="card-title">${element.title}</h3>
                    <h5 class="card-title">${element.instructor}</h5>
                    <p class="card-text text-center">${element.description}</p>
                    <h4 class="btn-warning text-center">${element.price}đ</h4>
                    <a href="#" class="btn btn-primary w-100"> Đăng kí ngay </a>
                    </div>
                </div>
            </div>
            `;
        });

        parent.innerHTML = content;
    })
    .catch(err => {
        console.log(err);
    })
}

display();